import React from "react";
import './App.css';

export default function HomePage() {
  return (
    <div className="p-6 space-y-10">
      <section className="text-center space-y-4">
        <h1 className="text-4xl font-bold">Talavera Therapy FC</h1>
        <p className="text-xl max-w-2xl mx-auto">
          Rebuilding lives through football. A trauma-informed therapy initiative for veterans and individuals with PTSD and C-PTSD.
        </p>
        <button className="text-lg bg-blue-600 text-white py-2 px-4 rounded">Join a Session</button>
      </section>
    </div>
  );
}
